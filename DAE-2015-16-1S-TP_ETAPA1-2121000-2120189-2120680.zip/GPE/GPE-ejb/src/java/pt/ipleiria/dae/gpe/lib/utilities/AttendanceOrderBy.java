/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.ipleiria.dae.gpe.lib.utilities;

/**
 *
 * @author joeld
 */
public enum AttendanceOrderBy {

    DateEndAsc, DateEndDesc, DateStartAsc, DateStartDesc, EventNameAsc, EventNameDesc,
    IsPresentAsc, IsPresentDesc, ManagerNameAsc, ManagerNameDesc, UCNameAsc, UCNameDesc

}
