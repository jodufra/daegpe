package pt.ipleiria.dae.gpe.lib.utilities;

public enum Room {
    
    //ROOM_A, ROOM_B("A.S.1.2B"), ROOM_C("A.S.1.2C"), ROOM_D("A.S.1.2D"), ROOM_E("A.S.1.2E"), ROOM_F("A.S.1.2F");
    
    R, A, C, D, P, Z
    /*private final String text;
    
    private Room(final String text)
    {
        this.text = text;
    }
    
    @Override
    public String toString()
    {
        return text;
    }*/
}
